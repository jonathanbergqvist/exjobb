/*
 * Molecule.cpp
 *
 *  Created on: Feb 10, 2016
 *      Author: claudio
 */

#include "Molecule.h"

Molecule::Molecule() {
	// TODO Auto-generated constructor stub

}

Molecule::~Molecule() {
	// TODO Auto-generated destructor stub
}

